<?php
define( 'GD_SITE_TOKEN', 'e19f0d4e-825d-4ad4-bbe1-96389aa0b022' );
define( 'GD_DC_ID', 'p3n' );
define( 'GD_TEMP_DOMAIN', 'w8g.a50.myftpupload.com' );
define( 'GD_NEXTGEN_ENABLED', FALSE );
define( 'GD_PLAN_NAME', 'basic_SSL' );
define( 'GD_SITE_CREATED', 1717093423 );
define( 'GD_MIGRATED_SITE', FALSE );
define( 'GD_HMT_SERVICE_KEY', 'ef476520-0d95-424d-94b2-66729edcfe66' );
define( 'GD_RESELLER', 1 );
define( 'GD_RUM_ENABLED', TRUE );
define( 'GD_VIP', '166.62.111.210' );
define( 'GD_ACCOUNT_UID', 'c8e82ea5-5539-4092-b1fb-4001e61268be' );
define( 'GD_GF_LICENSE_KEY', 'QbFuX95pocplfHDObMGVAnNxlFIUpm5d' );
define( 'GD_ASAP_KEY', '85782577e1bea7e1d9a505f3b8b98079' );
define( 'GD_CUSTOMER_ID', 'f1b7c6ba-e935-4428-b123-6f2904b34994' );
define( 'GD_CDN_ENABLED', TRUE );
define( 'GD_CDN_FULLPAGE', FALSE );
